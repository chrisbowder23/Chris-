// Backend server for managing users, appointments and sending SMS reminders.
//
// This Express application exposes a simple REST API to register users,
// authenticate them, create schedules (appointments), record check‑in/out
// times and automatically send reminder text messages via Twilio one hour
// before each appointment. Data is persisted in a JSON file using lowdb.

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const { Low, JSONFile } = require('lowdb');
const { v4: uuidv4 } = require('uuid');
const cron = require('node-cron');
const twilio = require('twilio');

// Load environment variables from .env file if present
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Middlewares
app.use(cors());
// Increase payload limit to allow for base64‑encoded images
app.use(bodyParser.json({ limit: '10mb' }));

// Initialise lowdb database
const file = new JSONFile('db.json');
const db = new Low(file);

async function initDb() {
  await db.read();
  // Set defaults if the JSON file is empty
  db.data ||= { users: [], appointments: [] };
  await db.write();
}

// Helper function to find a user by username
function findUser(username) {
  return db.data.users.find(u => u.username === username);
}

// Helper function to authenticate admin requests using a simple secret header
function isAdmin(req) {
  const adminSecret = req.headers['admin-secret'];
  return adminSecret && adminSecret === process.env.ADMIN_SECRET;
}

// Endpoint: register a new user (admin only)
// Expects: { username: string, password: string, phoneNumber: string }
app.post('/api/admin/registerUser', async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ error: 'Forbidden: invalid admin secret' });
  }
  const { username, password, phoneNumber } = req.body;
  if (!username || !password || !phoneNumber) {
    return res.status(400).json({ error: 'Missing username, password or phoneNumber' });
  }
  await initDb();
  // Check if user already exists
  if (findUser(username)) {
    return res.status(409).json({ error: 'User already exists' });
  }
  db.data.users.push({ username, password, phoneNumber });
  await db.write();
  res.json({ message: 'User registered successfully' });
});

// Endpoint: user login
// Expects: { username: string, password: string }
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Missing username or password' });
  }
  await initDb();
  const user = findUser(username);
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  // In a real application you would issue a JWT or session here.
  res.json({ message: 'Login successful' });
});

// Endpoint: create a new appointment for a user
// Expects: { username: string, dateTime: ISO8601 string }
app.post('/api/schedule', async (req, res) => {
  const { username, dateTime, photo } = req.body;
  if (!username || !dateTime) {
    return res.status(400).json({ error: 'Missing username or dateTime' });
  }
  const appointmentTime = new Date(dateTime);
  if (isNaN(appointmentTime.getTime())) {
    return res.status(400).json({ error: 'Invalid dateTime format' });
  }
  await initDb();
  const user = findUser(username);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  const appointment = {
    id: uuidv4(),
    username,
    time: appointmentTime.toISOString(),
    checkInTime: null,
    checkOutTime: null,
    reminderSent: false,
    // Store base64 encoded photo or null
    photo: photo || null
  };
  db.data.appointments.push(appointment);
  await db.write();
  res.json(appointment);
});

// Endpoint: record check‑in time for an appointment
// Expects: { username: string, appointmentId: string }
app.post('/api/checkin', async (req, res) => {
  const { username, appointmentId } = req.body;
  if (!username || !appointmentId) {
    return res.status(400).json({ error: 'Missing username or appointmentId' });
  }
  await initDb();
  const appointment = db.data.appointments.find(a => a.id === appointmentId && a.username === username);
  if (!appointment) {
    return res.status(404).json({ error: 'Appointment not found' });
  }
  appointment.checkInTime = new Date().toISOString();
  await db.write();
  res.json(appointment);
});

// Endpoint: record check‑out time for an appointment
// Expects: { username: string, appointmentId: string }
app.post('/api/checkout', async (req, res) => {
  const { username, appointmentId } = req.body;
  if (!username || !appointmentId) {
    return res.status(400).json({ error: 'Missing username or appointmentId' });
  }
  await initDb();
  const appointment = db.data.appointments.find(a => a.id === appointmentId && a.username === username);
  if (!appointment) {
    return res.status(404).json({ error: 'Appointment not found' });
  }
  appointment.checkOutTime = new Date().toISOString();
  await db.write();
  res.json(appointment);
});

// Endpoint: get all appointments for a user
app.get('/api/appointments/:username', async (req, res) => {
  const { username } = req.params;
  await initDb();
  const user = findUser(username);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  const appointments = db.data.appointments.filter(a => a.username === username);
  res.json(appointments);
});

// Endpoint: get all appointments with user data (for calendar view)
app.get('/api/calendar', async (req, res) => {
  await initDb();
  // Map appointments to include username and photo; exclude phone number for privacy
  const calendarEntries = db.data.appointments.map((a) => ({
    id: a.id,
    username: a.username,
    time: a.time,
    checkInTime: a.checkInTime,
    checkOutTime: a.checkOutTime,
    photo: a.photo
  }));
  res.json(calendarEntries);
});

// Initialise Twilio client if credentials are available
let twilioClient;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
  twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
}

// Cron job: run every minute to send reminders 1 hour before appointments
cron.schedule('* * * * *', async () => {
  await initDb();
  const now = new Date();
  for (const appointment of db.data.appointments) {
    if (!appointment.reminderSent) {
      const appointmentTime = new Date(appointment.time);
      const diffMs = appointmentTime.getTime() - now.getTime();
      const diffMinutes = diffMs / 60000;
      // If appointment is within the next hour (60 minutes) but in the future
      if (diffMinutes > 0 && diffMinutes <= 60) {
        const user = findUser(appointment.username);
        if (user && twilioClient && process.env.TWILIO_FROM_NUMBER) {
          try {
            await twilioClient.messages.create({
              to: user.phoneNumber,
              from: process.env.TWILIO_FROM_NUMBER,
              body: `Hi ${appointment.username}, this is a reminder that your scheduled time is at ${appointmentTime.toLocaleString()}. See you soon!`
            });
            appointment.reminderSent = true;
            await db.write();
            console.log(`Reminder sent to ${user.phoneNumber} for appointment ${appointment.id}`);
          } catch (err) {
            console.error('Error sending reminder:', err.message);
          }
        }
      }
    }
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});