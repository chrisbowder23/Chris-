import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, Image, StyleSheet, Alert } from 'react-native';
import axios from 'axios';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';

// Base URL for the backend API. Update this if your server runs on a different host/port.
const BASE_URL = 'http://localhost:3000';

const Stack = createStackNavigator();

// Login screen: prompts for username and password then navigates to Home on success.
function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!username || !password) {
      Alert.alert('Missing credentials', 'Please enter both username and password');
      return;
    }
    try {
      const response = await axios.post(`${BASE_URL}/api/login`, { username, password });
      if (response.data.message) {
        navigation.navigate('Home', { username });
      }
    } catch (err) {
      Alert.alert('Login failed', err.response?.data?.error || err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Login" onPress={handleLogin} />
      <View style={{ height: 10 }} />
      <Button title="Admin: Register User" onPress={() => navigation.navigate('AdminRegister')} />
    </View>
  );
}

// Admin registration screen: allows admin to create new users.
function AdminRegisterScreen({ navigation }) {
  const [adminSecret, setAdminSecret] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleRegister = async () => {
    if (!adminSecret || !username || !password || !phoneNumber) {
      Alert.alert('Missing fields', 'Please enter all fields');
      return;
    }
    try {
      const response = await axios.post(
        `${BASE_URL}/api/admin/registerUser`,
        { username, password, phoneNumber },
        { headers: { 'admin-secret': adminSecret } }
      );
      Alert.alert('Success', response.data.message || 'User registered');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Registration failed', err.response?.data?.error || err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin: Register User</Text>
      <TextInput
        style={styles.input}
        placeholder="Admin Secret"
        secureTextEntry
        value={adminSecret}
        onChangeText={setAdminSecret}
      />
      <TextInput
        style={styles.input}
        placeholder="New Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="New Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TextInput
        style={styles.input}
        placeholder="Phone Number (e.g. +15551234567)"
        keyboardType="phone-pad"
        value={phoneNumber}
        onChangeText={setPhoneNumber}
      />
      <Button title="Register" onPress={handleRegister} />
    </View>
  );
}

// Home screen: lists appointments and allows scheduling or checking in/out.
function HomeScreen({ route, navigation }) {
  const { username } = route.params;
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAppointments = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/api/appointments/${username}`);
      setAppointments(response.data);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
    const interval = setInterval(fetchAppointments, 30000); // refresh every 30 sec
    return () => clearInterval(interval);
  }, []);

  const handleCheckIn = async (appointmentId) => {
    try {
      const response = await axios.post(`${BASE_URL}/api/checkin`, {
        username,
        appointmentId
      });
      Alert.alert('Checked In', `Checked in at ${new Date().toLocaleString()}`);
      fetchAppointments();
    } catch (err) {
      Alert.alert('Check in failed', err.response?.data?.error || err.message);
    }
  };

  const handleCheckOut = async (appointmentId) => {
    try {
      const response = await axios.post(`${BASE_URL}/api/checkout`, {
        username,
        appointmentId
      });
      Alert.alert('Checked Out', `Checked out at ${new Date().toLocaleString()}`);
      fetchAppointments();
    } catch (err) {
      Alert.alert('Check out failed', err.response?.data?.error || err.message);
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Appointment at {new Date(item.time).toLocaleString()}</Text>
      <Text>Check‑in: {item.checkInTime ? new Date(item.checkInTime).toLocaleString() : '—'}</Text>
      <Text>Check‑out: {item.checkOutTime ? new Date(item.checkOutTime).toLocaleString() : '—'}</Text>
      <View style={styles.cardButtons}>
        <Button title="Check In" onPress={() => handleCheckIn(item.id)} disabled={!!item.checkInTime} />
        <Button title="Check Out" onPress={() => handleCheckOut(item.id)} disabled={!item.checkInTime || !!item.checkOutTime} />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome, {username}</Text>
      <Button title="Calendar" onPress={() => navigation.navigate('Calendar')} />
      <Button title="Add Appointment" onPress={() => navigation.navigate('AddAppointment', { username })} />
      {loading ? (
        <Text>Loading appointments…</Text>
      ) : (
        <FlatList
          data={appointments}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          ListEmptyComponent={<Text>No appointments scheduled</Text>}
        />
      )}
    </View>
  );
}

// Screen to create a new appointment
function AddAppointmentScreen({ route, navigation }) {
  const { username } = route.params;
  const [dateTime, setDateTime] = useState('');
  const [photoUri, setPhotoUri] = useState(null);
  const [photoBase64, setPhotoBase64] = useState(null);

  const pickImage = async () => {
    // Request permission to access media library
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Permission required', 'Permission to access the media library is required.');
      return;
    }
    // Launch the image picker
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.7,
    });
    if (!result.canceled) {
      const asset = result.assets[0];
      setPhotoUri(asset.uri);
      try {
        const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
        setPhotoBase64(base64);
      } catch (err) {
        console.error('Error reading image file:', err);
        Alert.alert('Error', 'Failed to process selected image');
      }
    }
  };

  const handleSchedule = async () => {
    if (!dateTime) {
      Alert.alert('Missing date/time', 'Please enter a date and time in ISO 8601 format (e.g. 2026-01-02T09:00:00)');
      return;
    }
    try {
      const response = await axios.post(`${BASE_URL}/api/schedule`, {
        username,
        dateTime,
        photo: photoBase64,
      });
      Alert.alert('Scheduled', `Appointment scheduled for ${new Date(response.data.time).toLocaleString()}`);
      navigation.goBack();
    } catch (err) {
      Alert.alert('Scheduling failed', err.response?.data?.error || err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Schedule Appointment</Text>
      <TextInput
        style={styles.input}
        placeholder="Appointment ISO date/time (YYYY-MM-DDTHH:MM:SS)"
        value={dateTime}
        onChangeText={setDateTime}
      />
      <Button title="Choose Photo" onPress={pickImage} />
      {photoUri && (
        <Image source={{ uri: photoUri }} style={{ width: 100, height: 100, marginVertical: 10 }} />
      )}
      <Button title="Schedule" onPress={handleSchedule} />
    </View>
  );
}

// Screen to display all appointments with photos (calendar view)
function CalendarScreen() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCalendar = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/api/calendar`);
      setEntries(response.data);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCalendar();
    const interval = setInterval(fetchCalendar, 60000); // refresh every minute
    return () => clearInterval(interval);
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      {item.photo ? (
        <Image
          source={{ uri: `data:image/jpeg;base64,${item.photo}` }}
          style={{ width: 60, height: 60, borderRadius: 30, marginRight: 10 }}
        />
      ) : (
        <View style={{ width: 60, height: 60, borderRadius: 30, backgroundColor: '#eee', marginRight: 10 }} />
      )}
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: 'bold' }}>{item.username}</Text>
        <Text>{new Date(item.time).toLocaleString()}</Text>
        <Text>
          Check‑in:{' '}
          {item.checkInTime ? new Date(item.checkInTime).toLocaleString() : '—'}
        </Text>
        <Text>
          Check‑out:{' '}
          {item.checkOutTime ? new Date(item.checkOutTime).toLocaleString() : '—'}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calendar</Text>
      {loading ? (
        <Text>Loading calendar…</Text>
      ) : (
        <FlatList
          data={entries}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          ListEmptyComponent={<Text>No appointments scheduled</Text>}
        />
      )}
    </View>
  );
}

// Root App component with navigation
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="AdminRegister" component={AdminRegisterScreen} options={{ title: 'Admin: Register' }} />
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Home' }} />
        <Stack.Screen name="AddAppointment" component={AddAppointmentScreen} options={{ title: 'Add Appointment' }} />
        <Stack.Screen name="Calendar" component={CalendarScreen} options={{ title: 'Calendar' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Basic styles for layout
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 4
  },
  card: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginVertical: 8,
    borderRadius: 4
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4
  },
  cardButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8
  }
});