# Cross‑platform appointment and check‑in mobile app

This project contains a full stack example of a cross‑platform mobile application for iOS and Android with a Node.js backend.  The app allows an administrator to create user accounts, end users to log in, schedule appointments, check in/out of appointments, and receive text‑message reminders one hour before the scheduled time.  The backend uses Twilio to send SMS reminders.

## Features

- **Cross‑platform client:** The front‑end is a React Native application that runs on both iOS and Android from a single codebase.  The official Flutter site notes that cross‑platform frameworks like Flutter enable you to build for iOS and Android simultaneously, reaching your full addressable market from a single code base【435382086352437†L56-L76】.  React Native provides similar cross‑platform capabilities using JavaScript.
- **User management:** An administrator can register new users by supplying a username, password and phone number.  A simple secret header is used to protect this endpoint.
- **Authentication:** Users can log in with their credentials.  This example uses a simple request to the server to verify the password; in a production app you would use secure authentication and tokens.
- **Scheduling:** Users can create appointments by providing a date/time.  These appointments are stored on the server.
- **Check‑in/out:** Users can record their check‑in and check‑out times for each appointment.
- **Automated SMS reminders:** A cron job runs on the server every minute to find appointments scheduled within the next hour and sends reminder texts via Twilio.  Twilio’s tutorial shows that appointment reminder applications automate the process of contacting customers before an appointment to reduce no‑shows【577106337206482†L197-L199】【577106337206482†L225-L228】.  The Node example demonstrates sending messages by specifying the `to`, `from` and `body` fields and calling `client.messages.create()`【400291672591034†L1182-L1187】【400291672591034†L1366-L1399】.

- **Photo attachments and calendar view:** Users can attach a photo when scheduling an appointment.  The mobile client uses Expo’s `ImagePicker` library to let you pick an image or take a photo; this library provides access to the system’s UI for selecting images or taking photos【536096894493236†L74-L103】.  The selected image is converted to a base64 string using Expo’s FileSystem API and stored with the appointment.  A calendar view in the app displays everyone’s appointments along with their photos and times.

## Directory structure

```
mobile_app/
├── backend/        # Node.js / Express server
│   ├── .env.example
│   ├── db.json
│   ├── package.json
│   └── server.js
├── frontend/       # React Native application
│   ├── App.js
│   └── package.json
└── README.md       # This file
```

## Prerequisites

- **Node.js** and **npm** installed on your computer.  The provided package.json files list the required dependencies.
- For the mobile app, you need the React Native CLI or Expo CLI and the Android/iOS SDKs set up.  Follow the official React Native setup guide for your platform.
- A Twilio account with an SMS‑enabled phone number.  Create a `.env` file in the `backend` directory based on `.env.example` and fill in your `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER` and an `ADMIN_SECRET` of your choosing.  Twilio’s documentation explains that before sending reminder messages you must configure your account credentials and obtain an SMS‑enabled number from the Twilio console【400291672591034†L236-L239】.

In order to support photo uploads, your React Native project needs the Expo ImagePicker and FileSystem libraries.  If you are using Expo (recommended for this feature), install them with:

```sh
npx expo install expo-image-picker expo-file-system
```

The ImagePicker module “provides access to the system's UI for selecting images and videos from the phone's library or taking a photo with the camera”【536096894493236†L74-L103】.  The FileSystem API allows you to read the selected image as a base64 string before uploading it to the server.

## Setup and running the backend

1. Navigate to the backend directory:

   ```sh
   cd mobile_app/backend
   ```

2. Copy the example environment file and fill in your values:

   ```sh
   cp .env.example .env
   # Edit .env to set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER and ADMIN_SECRET
   ```

3. Install the server dependencies:

   ```sh
   npm install
   ```

4. Start the server:

   ```sh
   npm start
   ```

   The server listens on port 3000 by default.  It will create a `db.json` file to persist users and appointments.  A cron job will run every minute to send SMS reminders one hour before each appointment.

## Setup and running the mobile app

1. Navigate to the frontend directory:

   ```sh
   cd mobile_app/frontend
   ```

2. Install dependencies:

   ```sh
   npm install
   ```

   If you are using Expo to leverage the photo feature, install the ImagePicker and FileSystem libraries:

   ```sh
   npx expo install expo-image-picker expo-file-system
   ```

3. Ensure the `BASE_URL` constant at the top of `App.js` points to your running backend.  If you are running on an emulator/device, you may need to replace `localhost` with your computer’s local IP address (for example `http://192.168.1.100:3000`).

4. Run the app on your desired platform using the React Native CLI.  For example:

   ```sh
   npx react-native run-android   # for Android
   npx react-native run-ios       # for iOS
   ```

   Alternatively, you can use Expo by creating a new Expo project and copying `App.js` into it.

## How it works

- **Admin registration:** Launch the app and tap “Admin: Register User”.  Enter the admin secret (matching `ADMIN_SECRET` in your `.env`), a username, password and the user’s phone number.  On success, the server stores the new user.
- **Login:** Return to the login screen, enter the user credentials and tap “Login”.  On success you will be taken to the home screen.
 - **Scheduling appointments:** Tap “Add Appointment” and enter a date/time in ISO 8601 format (e.g. `2026-01-02T09:00:00`).  You can optionally tap “Choose Photo” to select or capture an image.  The selected image is converted to a base64 string on the device (using Expo’s FileSystem API) and sent to the backend along with the appointment time.  The appointment will be created on the server with the photo attached.
- **Check‑in/out:** Back on the home screen your appointments are listed.  Use the “Check In” and “Check Out” buttons to record when you arrive and leave.
- **SMS reminders:** Each minute, the server looks for appointments scheduled within the next hour and sends a reminder via Twilio using the user’s phone number.  Twilio’s sample code illustrates constructing a message with `to`, `from` and `body` properties and calling `client.messages.create` to send it【400291672591034†L1182-L1187】【400291672591034†L1366-L1399】.  The message text can be customised in `server.js`.

- **Calendar view:** A dedicated calendar screen lists all appointments across users, showing each user’s name, the appointment time and the photo (if provided).  This allows administrators or users to see everyone’s schedule and associated images at a glance.

## Extending this example

This is a minimal proof‑of‑concept.  In a production environment you would likely:

* Implement proper authentication with JSON Web Tokens and secure password hashing.
* Allow users to pick dates and times via a native date picker instead of entering ISO strings.
* Persist data in a proper database rather than a JSON file.
* Deploy the backend to a server accessible from the mobile clients.
* Add error handling and input validation on both client and server.
* Secure the admin registration endpoint with authentication instead of a shared secret.

Nevertheless, this example demonstrates how you can combine a cross‑platform mobile front‑end with a Node.js backend to manage users, appointments and automated SMS reminders.